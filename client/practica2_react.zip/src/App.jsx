import "./App.css";
import { entries } from "./data.js";
import { CardList } from "./components/Cards.jsx";
import { useState} from "react"

function App() {
  const [filteredText, setFilteredText] = useState('');
  function handleChange(e){
    setFilteredText(e.target.value);

  }
  return (
    <>
      <h1>Mathy bloggg</h1>
      <div className = "filter">
        <p>Search: </p>
        <input type="text" value={filteredText} onChange={handleChange}></input>
      </div>
      <CardList entries={entries} filteredText={filteredText}> </CardList>
    </>
  )
}

export default App;