export function CardList({ entries, filteredText }) {
  const cards = entries.map((entry) => (
    entry.title.includes(filteredText) &&<Card
      key={entry.id}
      title={entry.title}
      date={entry.date}
      img={entry.img}
    />
  ));

  return <div className="card-list">{cards}</div>;
}

export function Card({ title, date, img }) {
  return (
    <div className="card">
      <img src={img} alt={title} />
      <h1>{title}</h1>
      <p>{date}</p>
    </div>
  );
}